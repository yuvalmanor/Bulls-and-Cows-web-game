/*
Authors �Oded Rinsky - 304973357, Yuval Manor -203537162
Project � Server
Description � The main c file of the server.
*/

#ifndef MAIN_H
#define MAIN_H
#include <stdio.h>
#include <string.h>
#include "serverManager.h"


#endif // !MAIN_H